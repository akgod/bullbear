const http = require("http");
const request = require("request");
const moment = require("moment");
const logger = console;
var Agent = require("socks5-https-client/lib/Agent");

var default_post_headers = {
  "content-type": "application/json;charset=utf-8",
};

var agentOptions = {
  keepAlive: true,
  maxSockets: 256,
  socksHost: "127.0.0.1",
  socksPort: 1086,
};
// var agentOptions = false;
exports.get = function (url, options) {
  // console.log(`${moment().format()} HttpGet: ${url}`)
  return new Promise((resolve, reject) => {
    options = options || {};
    var httpOptions = {
      url: url,
      method: "get",
      timeout: options.timeout || 3000,
      headers: options.headers || default_post_headers,
      proxy: options.proxy,
      agentClass: options.agent && agentOptions ? Agent : "",
      agentOptions: agentOptions,
    };
    request
      .get(httpOptions, function (err, res, body) {
        if (err) {
          reject(err);
        } else {
          if (res.statusCode == 200) {
            resolve(body);
          } else {
            reject(res.statusCode);
          }
        }
      })
      .on("error", logger.error);
  });
};

exports.post = function (url, postdata, options) {
  // console.log(`${moment().format()} HttpPost: ${url}`)
  return new Promise((resolve, reject) => {
    options = options || {};
    var httpOptions = {
      url: url,
      body: JSON.stringify(postdata),
      method: "post",
      timeout: options.timeout || 3000,
      headers: options.headers || default_post_headers,
      proxy: options.proxy || "",
      agentClass: options.agent && agentOptions ? Agent : "",
      agentOptions: agentOptions,
    };
    request(httpOptions, function (err, res, body) {
      if (err) {
        reject(err);
      } else {
        if (res.statusCode == 200) {
          resolve(body);
        } else {
          reject(res.statusCode);
        }
      }
    }).on("error", logger.error);
  });
};
exports.ajax = function (conf = {}) {
  // console.log(`${moment().format()} HttpPost: ${url}`)
  return new Promise((resolve, reject) => {
    let options = conf.options || {};
    var httpOptions = {
      url: conf.url,
      body: JSON.stringify(conf.body || {}),
      method: conf.method || "get",
      timeout: options.timeout || 3000,
      headers: options.headers || default_post_headers,
      proxy: options.proxy || "",
      agentClass: options.agent && agentOptions ? Agent : "",
      agentOptions: agentOptions,
    };
    request(httpOptions, function (err, res, body) {
      if (err) {
        reject(err);
      } else {
        if (res.statusCode == 200) {
          resolve(body);
        } else {
          reject(body);
        }
      }
    }).on("error", logger.error);
  });
};

exports.form_post = function (url, postdata, options) {
  // console.log(`${moment().format()} HttpFormPost: ${url}`)
  return new Promise((resolve, reject) => {
    options = options || {};
    var httpOptions = {
      url: url,
      form: postdata,
      method: "post",
      timeout: options.timeout || 3000,
      headers: options.headers || default_post_headers,
      proxy: options.proxy || "",
      agentOptions: agentOptions,
    };
    request(httpOptions, function (err, res, body) {
      if (err) {
        reject(err);
      } else {
        if (res.statusCode == 200) {
          resolve(body);
        } else {
          reject(res.statusCode);
        }
      }
    }).on("error", logger.error);
  });
};
