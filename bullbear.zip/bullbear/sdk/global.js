global.sleep = async (timeout) => {
  return new Promise((res, rej) =>
    setTimeout(() => {
      return res();
    }, timeout)
  );
};
